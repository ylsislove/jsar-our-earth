// let audioIndex = 0;
// spaceDocument.addEventListener('handtracking', (event) => {
//   const { inputData } = event;
//   // 右手拳头捏合
//   if (inputData.Type === 1 && inputData.Gesture === 1) {
//     if (audioIndex === 0) {
//       playEarthOrbitAudio()
//       audioIndex = 1
//     } else {
//       playEarthRotationAudio()
//       audioIndex = 0
//     }
//   }
// });
