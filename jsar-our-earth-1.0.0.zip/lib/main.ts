// // import { getEarthMat } from './matEarth';
// const scene = spaceDocument.scene as BABYLON.Scene;

// function clg(params:any) {
//   console.log('ylsislove', params);
// }

// // 地球平面材质
// const matEarthPlane = new BABYLON.StandardMaterial('matEarthPlane', scene);
// matEarthPlane.diffuseColor = new BABYLON.Color3(0, 1, 1);

// // 创建地球
// const earth = BABYLON.MeshBuilder.CreateSphere('earth', {
//   diameter: 4,
// }, scene);
// // 创建地球赤道平面
// const earthPlane = BABYLON.MeshBuilder.CreateDisc("earthPlane", {
//   radius: 4,
//   tessellation: 64,
//   sideOrientation: BABYLON.Mesh.DOUBLESIDE
// }, scene);
// earthPlane.setParent(earth);
// // 设置地球材质
// // getEarthMat().then(mat => earth.material = mat);
// earthPlane.material = matEarthPlane;
// earth.rotate(new BABYLON.Vector3(1, 0, 0), -(60/180*Math.PI), BABYLON.Space.LOCAL);
// earthPlane.rotate(new BABYLON.Vector3(1, 0, 0), -(90/180*Math.PI), BABYLON.Space.LOCAL);

// var alpha = Math.PI;
// scene.registerBeforeRender(function () {
//   earth.rotate(new BABYLON.Vector3(0, 1, 0), 0.01, BABYLON.Space.LOCAL);
//   alpha += 0.01;
// })

// // const earthRotationAnimation = new BABYLON.Animation(
// //   'earthRotation',
// //   'rotation',
// //   60,
// //   BABYLON.Animation.ANIMATIONTYPE_VECTOR3,
// //   BABYLON.Animation.ANIMATIONLOOPMODE_CYCLE
// // );
// // const keyFrames = []; 
// // keyFrames.push({
// //   frame: 0,
// //   value: earth.rotation
// // });
// // keyFrames.push({
// //   frame: 60,
// //   value: earth.rotation.add(new BABYLON.Vector3(0, 2*Math.PI, 0))
// // });
// // earthRotationAnimation.setKeys(keyFrames);
// // earth.animations.push(earthRotationAnimation);
// // scene.beginAnimation(earth, 0, 60, true, 0.25);
