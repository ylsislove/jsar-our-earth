// import earth from '../texture/Day/Earth-Day.png';

// export async function getEarthMat() {
//     // 读取图片
//     const bitmap = await createImageBitmap(new Blob([earth], { type: 'image/png' }))
//     // 创建画布
//     const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
//     const ctx = canvas.getContext('2d');
//     // 绘制图片
//     ctx.drawImage(bitmap, 0, 0);
//     const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
//     // 创建纹理
//     const texture = new BABYLON.RawTexture(
//         imageData.data,
//         imageData.width,
//         imageData.height,
//         BABYLON.Engine.TEXTUREFORMAT_RGBA,
//         spaceDocument.scene,
//         false,
//         false,
//         BABYLON.Texture.TRILINEAR_SAMPLINGMODE
//     );
//     // 创建材质
//     const material = new BABYLON.StandardMaterial('matEarth', spaceDocument.scene);
//     material.diffuseTexture = texture;
//     // 返回材质
//     return material;
// };
